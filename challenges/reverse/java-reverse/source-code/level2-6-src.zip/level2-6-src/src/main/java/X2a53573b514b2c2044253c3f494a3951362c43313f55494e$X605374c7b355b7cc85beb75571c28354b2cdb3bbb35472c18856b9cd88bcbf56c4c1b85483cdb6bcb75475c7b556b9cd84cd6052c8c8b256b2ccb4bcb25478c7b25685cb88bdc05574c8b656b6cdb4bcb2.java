import org.apache.commons.codec.binary.Hex;

import java.lang.reflect.Modifier;

public class X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2 {
    public static Boolean X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5(){
        try {
            String hc = new String(Hex.encodeHex(X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X544768bba749abc079b2ab4965b67748a6c1a7afa74866b57c4aadc17cb0b34ab8b5ac4877c1aab0ab4869bba94aadc178c154466bb8754975beb4b0ac4568b5a64aaac1a5.class.getDeclaredMethod("X362997998c298c975e9388289e9b90305ba68c965a2b9e995a308b975e9688289b9b8e305ba38a").toGenericString().getBytes()));
            if(!hc.equals(X240d120e4e180a0701375205235c21321c3314593631$X25030f014430.X010915("0"))){
                throw new RuntimeException();
            }
            if (!Modifier.isPrivate(X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X544768bba749abc079b2ab4965b67748a6c1a7afa74866b57c4aadc17cb0b34ab8b5ac4877c1aab0ab4869bba94aadc178c154466bb8754975beb4b0ac4568b5a64aaac1a5.class.getDeclaredMethod("X362997998c298c975e9388289e9b90305ba68c965a2b9e995a308b975e9688289b9b8e305ba38a").getModifiers())){
                throw new RuntimeException();
            }
            if (Main.class.getResource("/config.conf") == null){
                throw new RuntimeException();
            }
        } catch (Exception e) {
            throw new RuntimeException();
        }
        return true;
    }
}