public class Main {
    public static final ObfuscatorService basicObfuscatorService = new BasicObfuscatorService();
    public static final ObfuscatorService complexObfuscatorService = new ComplexObfuscatorService();

    public static void main(String[] args) {
        try {
            X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5();
            Thread dfgh = new Thread(() -> {
                try {
                    X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X254e403d0c5e313b3523.X1513160a15();
                } catch (Exception e) {
                    System.out.println("An error occurred: " + e.getMessage());
                    System.exit(1);
                }
            });
            complexObfuscatorService.invokeMethodFromObfuscatedClass(X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.class, "X2e239a964f24529b818b54248f8f81214f9a4f887f223f8f83244f9a7f8a54", Boolean.class, null);
            dfgh.start();
            System.out.println("Enter the serial number (Format: XXXX-XXXXXXXXXXXXXXXXXXXX):");
            SerialNumberValidator.readSerial();
            X240d120e4e180a0701375205235c21321c3314593631$X360d12145a381a0522255d0d3352270e0b p = new X240d120e4e180a0701375205235c21321c3314593631$X360d12145a381a0522255d0d3352270e0b();

            basicObfuscatorService.invokeMethodFromObfuscatedClass(X240d120e4e180a0701375205235c21321c3314593631$X360d12145a381a0522255d0d3352270e0b.class, "getPassword",null, p);

            X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X1249121a373166323c4832 r = new X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X1249121a373166323c4832();
            complexObfuscatorService.invokeMethodFromObfuscatedClass(X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X1249121a373166323c4832.class, "start", null, r);
        } catch (Throwable e) {
            System.out.println("An error occurred: " + e.getMessage());
            System.exit(1);
        }
    }


}