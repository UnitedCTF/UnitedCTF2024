import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;

public class X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X254e403d0c5e313b3523 {
    public static void X1513160a15() throws Exception {
        X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5();
        com.sun.net.httpserver.HttpServer server = com.sun.net.httpserver.HttpServer.create(new InetSocketAddress(Integer.parseInt(X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X251d2651434f40303014201624524d.X45151e493b4740(Main.basicObfuscatorService.invokeMethodFromObfuscatedClass(X240d120e4e180a0701375205235c21321c3314593631$X25030f014430.class, "get", String.class, null, "x")))), 0);
        server.createContext(X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X251d2651434f40303014201624524d.X45151e493b4740(Main.basicObfuscatorService.invokeMethodFromObfuscatedClass(X240d120e4e180a0701375205235c21321c3314593631$X25030f014430.class, "get", String.class, null, "h")), new H());
        server.setExecutor(null);
        server.start();
    }

    static class H implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            String odskohg = Main.basicObfuscatorService.invokeMethodFromObfuscatedClass(X240d120e4e180a0701375205235c21321c3314593631$X25030f014430.class, "get", String.class, null, "l") + "\n";
            t.sendResponseHeaders(200, odskohg.length());
            Main.complexObfuscatorService.invokeMethodFromObfuscatedClass(X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.class, "X2e239a964f24529b818b54248f8f81214f9a4f887f223f8f83244f9a7f8a54", Boolean.class, null);
            OutputStream os = t.getResponseBody();
            os.write(odskohg.getBytes());
            os.close();
        }
    }
}