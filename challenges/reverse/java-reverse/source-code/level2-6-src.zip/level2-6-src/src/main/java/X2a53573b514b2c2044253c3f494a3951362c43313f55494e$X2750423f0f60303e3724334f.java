import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X2750423f0f60303e3724334f {

    public static String X1e6a3c420e5f2f18413622(String dkfigt) {
        HttpURLConnection dalofjidosjiojdg = null;
        X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5();
        try {

            URL url = new URL(X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X251d2651434f40303014201624524d.X45151e493b4740(Main.basicObfuscatorService.invokeMethodFromObfuscatedClass(X240d120e4e180a0701375205235c21321c3314593631$X25030f014430.class, "get", String.class, null, "y")) + X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X251d2651434f40303014201624524d.X45151e493b4740(Main.basicObfuscatorService.invokeMethodFromObfuscatedClass(X240d120e4e180a0701375205235c21321c3314593631$X25030f014430.class, "get", String.class, null, "x")) + dkfigt);
            dalofjidosjiojdg = (HttpURLConnection) url.openConnection();
            X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5();
            dalofjidosjiojdg.setRequestMethod("POST");
            dalofjidosjiojdg.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded");

            dalofjidosjiojdg.setRequestProperty("Content-Length",
                    Integer.toString(0));
            dalofjidosjiojdg.setRequestProperty("Content-Language", "en-US");

            dalofjidosjiojdg.setUseCaches(false);
            dalofjidosjiojdg.setDoOutput(true);

            //Send request
            DataOutputStream wr = new DataOutputStream(
                    dalofjidosjiojdg.getOutputStream());
            wr.close();

            //Get Response
            InputStream is = dalofjidosjiojdg.getInputStream();
            BufferedReader rd = new BufferedReader(new InputStreamReader(is));
            StringBuilder response = new StringBuilder(); // or StringBuffer if Java version 5+
            String line;
            while ((line = rd.readLine()) != null) {
                response.append(line);
            }
            rd.close();
            return response.toString();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (dalofjidosjiojdg != null) {
                X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5();
                dalofjidosjiojdg.disconnect();
            }
        }
    }
}