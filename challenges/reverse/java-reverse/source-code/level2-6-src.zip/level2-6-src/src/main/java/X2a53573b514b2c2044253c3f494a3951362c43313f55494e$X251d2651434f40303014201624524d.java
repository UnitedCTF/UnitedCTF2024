import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;

import java.io.ByteArrayOutputStream;
import java.util.*;
import java.util.stream.Collectors;

public class X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X251d2651434f40303014201624524d {
    public static String X45151e493b4740(String s) {
        byte[] sx = new byte[0];
        try {
            sx = Hex.decodeHex(s);
        } catch (DecoderException e) {
            throw new RuntimeException(e);
        }
        Base64.Decoder e = Base64.getDecoder();
        byte[] mn = Arrays.stream(new String(e.decode(sx)).split(" ")).map(Byte::parseByte).mapToInt(m -> m).map(i -> Integer.valueOf(i).byteValue()).collect(ByteArrayOutputStream::new, (baos, i) -> baos.write((byte) i),
                        (baos1, baos2) -> baos1.write(baos2.toByteArray(), 0, baos2.size()))
                .toByteArray();
        List<Byte> l = new ArrayList<>();
        for (byte n : mn) {
            l.add(n);
        }
        X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5();
        mn = l.stream().map(b -> String.valueOf(b)).map(s1 -> Integer.parseInt(String.valueOf(s1.charAt(1)))).map(x -> {
                    int[] k = new int[40];
                    int lz = 0;
                    while (x > 0) {
                        k[lz++] = x % 2;
                        x = x / 2;
                    }
                    return (k[0]);
                }).mapToInt(m -> m).map(i -> Integer.valueOf(i).byteValue()).collect(ByteArrayOutputStream::new, (baos, i) -> baos.write((byte) i),
                        (baos1, baos2) -> baos1.write(baos2.toByteArray(), 0, baos2.size()))
                .toByteArray();
        String sg = "";
        int bbb = 0;
        for (byte n : mn) {
            sg += String.valueOf(n);
            bbb++;
            if (bbb == 0x16 >> 3 << 2) {
                sg += " ";
                bbb = 0;
            }
        }
        byte[] klf = Arrays.stream(sg.split(" ")).mapToInt(s1 -> Integer.parseInt(s1, 2)).map(i -> Integer.valueOf(i).byteValue()).collect(ByteArrayOutputStream::new, (baos, i) -> baos.write((byte) i),
                (baos1, baos2) -> baos1.write(baos2.toByteArray(), 0, baos2.size())).toByteArray();
        String[] slg = Arrays.stream(X4309316444(klf, X46180d3814490f2635())).map(i -> Integer.valueOf(i).byteValue()).collect(ByteArrayOutputStream::new, (baos, i) -> baos.write((byte) i),
                (baos1, baos2) -> baos1.write(baos2.toByteArray(), 0, baos2.size())).toString().split(";");
        List<Character> bld = Arrays.stream(slg).map(sfsd -> (char) Byte.parseByte(sfsd)).collect(Collectors.toList());
        sg = "";
        X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5();
        for (char c : bld) {
            sg += c;
        }
        mn = Arrays.stream(sg.split("")).mapToInt(s1 -> Integer.parseInt(s1)).map(i -> i % 7).map(i -> Integer.valueOf(i).byteValue()).collect(ByteArrayOutputStream::new, (baos, i) -> baos.write((byte) i),
                (baos1, baos2) -> baos1.write(baos2.toByteArray(), 0, baos2.size())).toByteArray();
        sg = "";
        for (byte n : mn) {
            sg += String.valueOf(n);
            bbb++;
            if (bbb == 0x16 >> 3 << 2) {
                sg += " ";
                bbb = 0;
            }
        }
        try {
            X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.class.getMethod("X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5").invoke(null);
        }catch (Exception ex){
            throw new RuntimeException();
        }
        klf = Arrays.stream(sg.split(" ")).mapToInt(s1 -> Integer.parseInt(s1, 2)).map(i -> Integer.valueOf(i).byteValue()).collect(ByteArrayOutputStream::new, (baos, i) -> baos.write((byte) i),
                (baos1, baos2) -> baos1.write(baos2.toByteArray(), 0, baos2.size())).toByteArray();
        List<Byte> l2 = new ArrayList<>();
        for (byte n : klf) {
            l2.add(n);
        }
        String kgs = new String(klf);
        byte[] slh = Arrays.stream(kgs.split("")).mapToInt(sdf -> Integer.parseInt(sdf)).map(i -> Integer.valueOf(i).byteValue()).filter(v -> X2a53573b514b2c2044253c3f494a3951362c43313f55494e$X605374c7b355b7cc85beb75571c28354b2cdb3bbb35472c18856b9cd88bcbf56c4c1b85483cdb6bcb75475c7b556b9cd84cd6052c8c8b256b2ccb4bcb25478c7b25685cb88bdc05574c8b656b6cdb4bcb2.X4e4166b0a1476fb09fab7041b5b5a24772afa69f7444b5b0a44876af6f9fa541b2b676476fbb6f9fae4663b0a24176af6f9fa341b5b676476fbe6f9f7544b5()).collect(ByteArrayOutputStream::new, (baos, i) -> baos.write((byte) i),
                (baos1, baos2) -> baos1.write(baos2.toByteArray(), 0, baos2.size())).toByteArray();
        int[] kfjs = X4309316444(slh, new byte[]{0x1});
        byte[] kjhgo = Arrays.stream(kfjs).map(i -> Integer.valueOf(i).byteValue()).collect(ByteArrayOutputStream::new, (baos, i) -> baos.write((byte) i),
                (baos1, baos2) -> baos1.write(baos2.toByteArray(), 0, baos2.size())).toByteArray();
        String lpgo = "";
        for (byte n : kjhgo) {
            lpgo += String.valueOf(n);
            bbb++;
            if (bbb == 0x16 >> 3 << 2) {
                lpgo += " ";
                bbb = 0;
            }
        }
        byte[] klglphl = Arrays.stream(lpgo.split(" ")).mapToInt(s1 -> Integer.parseInt(s1, 2)).map(i -> Integer.valueOf(i).byteValue()).collect(ByteArrayOutputStream::new, (baos, i) -> baos.write((byte) i),
                (baos1, baos2) -> baos1.write(baos2.toByteArray(), 0, baos2.size())).toByteArray();
        return new String(e.decode(klglphl));
    }

    private static byte[] X46180d3814490f2635() {
        try {
            return Hex.decodeHex(new String(new byte[]{0x37,50,066,102,0x37,064,0x36,49,55,0x34,066,0x35,0x37,064,0x36,070,0x36,49,067,0x34}));
        } catch (DecoderException e) {
            throw new RuntimeException(e);
        }
    }

    private static int[] X4309316444(byte[] okdodr, byte[] jdhsjf) {
        int[] lkgbo = new int[okdodr.length];
        for (int i = 0; i < okdodr.length; i++) {
            lkgbo[i] = okdodr[i] ^ jdhsjf[i % jdhsjf.length];
        }
        return lkgbo;
    }
}