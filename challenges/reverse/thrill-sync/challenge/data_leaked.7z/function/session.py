class Session:
    def __init__(self):
        self.connected = False
        self.logged_in = False
        self.token = None


